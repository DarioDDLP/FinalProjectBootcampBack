This template / effect / code has been created by agathaco.
You can customize and check it out on its original site on the following link:
https://codepen.io/agathaco/pen/eLOKvr

Thank you